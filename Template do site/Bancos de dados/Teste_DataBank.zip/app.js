var checkbox = document.querySelector("input[name=checkbox]");

checkbox.addEventListener( 'change', function logado() {
    if(this.checked) {
        let logado = true;
        alert("Usuário logado!");
    } else {
        let logado = false;
        alert("Usuário não logado!");
    }
});
if(logado=true){
function leDados () { /* Função que lê os dados já existentes */
    let strDados = localStorage.getItem('telaForum');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = { publicacao: [ 
                        {Nome: "User_ID", 
                        Publicação: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consequat et augue in facilisis. Mauris porttitor, quam vel euismod porta, elit sapien suscipit odio, nec vehicula augue lorem at mi. Sed ac facilisis erat. Curabitur tempus eleifend metus a placerat. Ut eu nisi non nisl maximus egestas non non nulla.'}
                    ]}
    }

    return objDados;
}

function salvaDados (dados) { /* Função que salva os dados em formato String */
    localStorage.setItem ('telaForum', JSON.stringify (dados));
}

function incluirContato (){/* Função que lê e salva os dados postados na página */
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir um novo contato
    let strNome = document.getElementById ('campoNome').value;
    let strPub = document.getElementById ('pub').value;
    let novaPub = {
        Nome: strNome,
        Publicação: strPub
    };
    objDados.publicacao.push (novaPub);

    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
}

function imprimeDados () { /* Função mostra os dados postados em uma div especifica */
    let tela = document.getElementById('verForum');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.publicacao.length; i++) {
        strHtml += `<div id="post"><p>${objDados.publicacao[i].Nome}: <br> ${objDados.publicacao[i].Publicação}<br></p></div>`
    }

    tela.innerHTML = strHtml;
}

// Configura os botões
document.getElementById ('verPub').addEventListener ('click', imprimeDados);/* Botão que mostra as pub's */
document.getElementById ('publicar').addEventListener ('click', incluirContato);/* Botão que publica a postagem */

}
else{
    addEventListener('click' ,alert("Usuário não logado!"));
    
}