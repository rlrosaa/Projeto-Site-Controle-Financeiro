function leResposta(getElementById='pubResposta'){
    let strResp = localStorage.getItem('pubResposta');
    let objResp= {};

    if(strResp){
        objResp = JSON.parse(strResp);
    }
    else{
        objResp = {
            resposta : [
                {Nome: "User_ID",
                Resposta: 'Resposta blablablablablablablablablablablablablablablablablablablablabla.'}
            ]
        }
    }
    return objResp;
}
function salvaResposta(dados){
    localStorage.setItem('pubResposta', JSON.stringify (dados));
}
function IncluirResposta(){
    //Ler os dados do localStorage
    let objResp = leResposta();

    //Inclui uma nova Resposta ao tópico
    let strResp = document.getElementById('pubResposta').value;
    let novaResp = {
        Resposta: strResp};
    objResp.resposta.push(novaResp);

    //Salva os dados no LocalStorage novamente
    salvaResposta(objResp);

    //Atualiza os dados da tela
    imprimeResposta();
}
function imprimeResposta(){
    let telaResp = document.getElementById('verResposta');
    let strHtml_Resp = '';
    let objResp = leResposta();

    for(i=0; i<objResp.resposta.length; i++){
        strHtml_Resp +=`<div id="postResp"><p>${objResp.resposta[i].Resposta}: <br></div>`
    }
    telaResp.innerHTML = strHtml_Resp;

}
document.getElementById ('responder').addEventListener ('click', IncluirResposta);/* Botão que publica a postagem */
document.getElementById ('verRes').addEventListener ('click', imprimeResposta);




