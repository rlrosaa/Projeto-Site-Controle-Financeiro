function validaLogin (){
    var user =document.getElementById("login").value.toUpperCase();
    var senha = document.getElementById("passW").value;
    if(user==""){
        alert ("Favor preencher nome de usuario.");        
    }
    else if (senha == ""){   
        alert ("Favor preencher a senha.");
    }
    else{
        objDados = leDados();
        let login = false;
        let txtErr = "Usuario não encontrado. Realizar Cadastro.";
        let userNL = 0;
        for (i=0;i<objDados.contatos.length;i++){
            if (user==objDados.contatos[i].user){
                
                if(senha == objDados.contatos[i].senha){
                    login = true;
                    userNL = i;
                }
                else{
                    txtErr = "Senha incorreta!";
                }                
            }
        }    
        if (login){            
            registraLogin(userNL,objDados);
            window.location.href = "tela_inicial.html"
        }
        else{
            alert(txtErr)
        }
    }

}

function validaCadastro(){
    
    let nNome = document.getElementById("nNome").value;
    let nUser = document.getElementById("nUser").value.toUpperCase();
    let nSenha = document.getElementById("nPassW").value;
    let nSenha2 = document.getElementById("nPassW2").value;


    if(nNome==""){
        alert ("Favor preencher nome completo do usuario.");        
    }
    else if(nUser==""){
        alert ("Favor preencher nome de usuario.");        
    }
    else if (nSenha == ""){   
        alert ("Favor preencher a senha.");
    }
    else if (nSenha != nSenha2){   
        alert ("Verificação de senha incorreta.");
    }
    else{
        objDados = leDados();
        let add = true;
        for (i=0;i<objDados.contatos.length;i++){
            if (nUser==objDados.contatos[i].user){
                alert ("Usuario já existente.");
                add = false;
                break;
            }                        
        }
        if (add){
            incluirDados(nNome,nUser,nSenha,objDados);
            alert("Cadastro Realizado com sucesso")
            window.location.href = "tela_login.html";
        }  
    }

}

function leDados(){

    let strDados = localStorage.getItem("db");
    let objDados = {};

    if (strDados){
        objDados = JSON.parse(strDados);
    }
    else{
        objDados = {contatos: [
            {nome: "User Adm", user: "adm", senha: "adm",login: "false"}
        ]}
    }
    return objDados;
}

function incluirDados(nNome,nUser,nSenha,objDados){
    
    let novoContato = {
        nome: nNome,
        user: nUser,
        senha: nSenha,
        login: "false"
    };
    
    objDados.contatos.push(novoContato);
    salvaDados(objDados);
}

function salvaDados(objDados){

    strDados = JSON.stringify(objDados);
    localStorage.setItem('db',strDados);


}
function limpaDados(){
    localStorage.setItem('db',"");
    localStorage.setItem('numUser',"");
    alert("limpo");
}

function registraLogin(numUser,objDados){
    objDados.contatos[numUser].login = "true"
    salvaDados(objDados);
    localStorage.setItem('numUser',numUser);
}

function registraLogout(){
    objDados = leDados();
    numUser = localStorage.getItem('numUser')
    objDados.contatos[numUser].login = "false"
    salvaDados(objDados);
    localStorage.setItem('numUser',"");
}

function testPageInicial(){

    let numUser = localStorage.getItem("numUser");
    let objDados = leDados();
    let txtUser = "";
    let txtBTT="";

    if(numUser != "" && numUser != null){
        if(objDados.contatos[numUser].login == "true"){
            txtUser = "<b>Usuario: </b>" + objDados.contatos[numUser].nome;
            txtBtt = "Sair";
        }
    }

    if(txtUser == ""){
        txtUser = "Usuário não Logado";
        txtBtt= "Login";
    }

    document.getElementById("txtTLInicial").innerHTML=txtUser
    document.getElementById("btTLInicial").innerHTML=txtBtt
}

function clickLogin(){

    txtBtt = document.getElementById("btTLInicial").innerHTML
    if (txtBtt == "Login"){
        window.location.href = "tela_login.html"
    }
    else if (txtBtt == "Sair"){
        let logout = confirm("Realmente deseja fazer logout?");
        if(logout){
            registraLogout();
            alert ("Logout realizado");
            window.location.reload();
        }
    }
}