function teste (){
    var num = document.getElementById("txtTLInicial").innerHTML;
    //alert(num);
    //let num2 = parseFloat(num);
    num++;
    document.getElementById("txtTLInicial").innerHTML=num;
}