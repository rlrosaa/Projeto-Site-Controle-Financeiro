function leDados () { /* Função que lê os dados já existentes */
    let strDados = localStorage.getItem('telaForum');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = { publicacao: [ 
                        //{Titulo: "", 
                        //Publicação: ''}
                    ]}
    }

    return objDados;
}

function salvaDados (dados) { /* Função que salva os dados em formato String */
    localStorage.setItem ('telaForum', JSON.stringify (dados));
}

function incluirContato (){/* Função que lê e salva os dados postados na página */
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir um novo contato
    let strTitulo = document.getElementById ('campoTitulo').value;
    let strPub = document.getElementById ('pub').value;
    let novaPub = {
        Titulo: strTitulo,
        Publicação: strPub
    };
    objDados.publicacao.push (novaPub);

    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
}

function imprimeDados () { /* Função mostra os dados postados em uma div especifica */
    let tela = document.getElementById('verForum');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.publicacao.length; i++) {
        strHtml += `<div id="post"><div id="nome"><h1>${objDados.publicacao[i].Titulo}</h1></div><p>${objDados.publicacao[i].Publicação}</p></div>`
    }

    tela.innerHTML = strHtml;
}

// Configura os botões
document.getElementById ('verPub').addEventListener ('click', imprimeDados);/* Botão que mostra as pub's */
document.getElementById ('publicar').addEventListener ('click', incluirContato);/* Botão que publica a postagem */
