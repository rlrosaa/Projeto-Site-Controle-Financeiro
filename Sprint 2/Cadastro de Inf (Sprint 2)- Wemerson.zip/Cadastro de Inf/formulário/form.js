function leDados () { /* Função que lê os dados já existentes */
    let strDados = localStorage.getItem('formulario');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse(strDados);
    }
    else {
        objDados = {Formulario:{
            Nome_completo:'Jhon Doe Does',
            Genero:"Masculino",
            Data_nascimento: '30/12/2000',
            Tipo_usuario: 'Profissinal',
            Renda: '2000.00',
            Contas_fixas:'1200.50',
            Estudo:'200.00',
            Investir:'10.15'

        }}
    }

    return objDados;
}

function salvaDados (dados) { /* Função que salva os dados em formato String */
    localStorage.setItem ('formulario', JSON.stringify (dados));
}

function incluirContato (){/* Função que lê e salva os dados postados na página */
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir um novo contato
    let strNome = document.getElementById ('form_name').value;
    let strGenero = document.getElementById ('form_genero').value;
    let strNasc = document.getElementById ('nascimento').value;
    let strUser = document.querySelector('input[name="tipo_usuario"]:checked').value;
    let strRenda = document.getElementById ('renda').value;
    let strContas = document.getElementById ('contas').value;
    let strEstudo = document.getElementById ('educacao').value;
    let strInvestir = document.getElementById ('investe').value;

    let novaDado = {
        Nome: strNome,
        Genero: strGenero,
        Data_nascimento: strNasc,
        Tipo_usuario: strUser,
        Renda: strRenda,
        Contas_fixas: strContas,
        Estudo: strEstudo,
        Investir: strInvestir     
    };
    objDados.Formulario.push (novaDado);

    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
}

function imprimeDados () { /* Função mostra os dados postados em uma div especifica */
    let tela = document.getElementById('verForm');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.Formulario.length; i++) {
        strHtml += `<p>${objDados.Formulario[i].Nome_completo}: <br> 
                       ${objDados.Formulario[i].Genero}<br> 
                       ${objDados.Formulario[i].Data_nascimento}<br>
                       ${objDados.Formulario[i].Tipo_usuario}<br>
                       ${objDados.Formulario[i].Renda}<br>
                       ${objDados.Formulario[i].Contas_fixas}<br>
                       ${objDados.Formulario[i].Estudo}<br>
                       ${objDados.Formulario[i].Investir}<br>
                    </p>`
    }

    tela.innerHTML = strHtml;
}

// Configura os botões
document.getElementById ('ver').addEventListener ('click', imprimeDados);/* Botão que mostra as pub's */
document.getElementById ('enviar').addEventListener ('click', incluirContato);/* Botão que publica a postagem */

