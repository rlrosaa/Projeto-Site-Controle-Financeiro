Olá.
O site foi publicado na internet pelo github pages.
Para acessar usar o link: https://lucassimplicio.github.io (lembra de colocar dois 's').
Para a Sprint-3 (adição de dinâmicas com JavaScript) eu fiz:
.um aviso nas funções e páginas que estão em desenvolvimento.
.Dados (fictícios) no gráfico monetário, dados esses que aparecem de uma forma diferenciada.
.opção de retirar algumas partes do gráfico.

Para testar essas dinâmicas JavaScript:

1) Extraia tudo da pasta para um local de sua preferencia.
2) Leia o arquivo de texto.
3) Acesse o site pelo link ou utilizando os arquivos da pasta artefatos_de_codigos no Visual Studio.
4) Ao acessar a página clique em algumas palavras com "login", "cadastro", nos nomes das dicas e nos botões para ver os avisos (primeira dinâmica).
5) Para testar a parte do gráfico passe com o curso por cima das fatias do gráfico para ver seus valores (segunda dinâmicas).
6) Clique nos valores em cima do gráfico para retira-lo do gráfico (terceira dinâmicas).

Obs: .As páginas das dicas, cadastro e login não foram criadas porque não eram o foco para essa Sprint.
.Não tenho certeza se conta como dinâmica (esqueci de perguntar pro professor) mas quando você clica na foto de usuário 
no canto superior esquerdo da tela aparece algumas opções.
.Esqueci de olhar a recursividade do novo gráfico, mas na avaliação não fala nada sobre recursividade então...

Obrigado.
Lucas Henrique Simplicio Monteiro
