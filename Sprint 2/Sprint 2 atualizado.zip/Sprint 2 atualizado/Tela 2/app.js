function leDados () {
    let strDados = localStorage.getItem('tipodeinvestimento');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = { planos: [ 
            {
                idPlano: "renda fixa",
                Caracteristica: " A Renda Fixa é uma modalidade de investimento para quem procura segurança e bons retornos. O investimento é realizado diretamente em Títulos Públicos e Privados de Renda Fixa. Por exemplo, quando você compra um título, está emprestando dinheiro ao emissor do papel, que pode ser um banco, uma empresa ou até mesmo o governo.",
                Vencimento: "mensalmente",
                AporteInicial: "30,00 reais",
                Perfil: "conservador"
              },
              {
                idPlano: "Fundos imobiliários",
                Caracteristica: "Os Fundos de Investimento Imobiliário (FII) são compostos por grupos de investidores que possuem o objetivo de aplicar recursos em diversos tipos de investimentos imobiliários, seja no desenvolvimento de empreendimentos, em imóveis já prontos – como edifícios comerciais, shopping centers e hospitais (Fundos de Tijolo), ou até mesmo em títulos de dívida imobiliários (Fundos de papel).",
                Vencimento: "mensal",
                "AporteInicial": "20,00",
                Perfil: "arrojado"
              },
              {
                idPlano: "Previdencia Privada",
                Caracteristica: "A Previdência Privada é uma forma de investimento em que você contribui com uma quantia em dinheiro por um determinado período, e esse valor é rentabilizado de acordo com o plano escolhido. Os pagamentos podem ser mensais, de uma só vez ou, ainda, portabilizados de um plano já existente em outra instituição. Lembre-se de que, quanto mais você investir durante um tempo maior, mais seu patrimônio cresce.",
                Vencimento: "mensal",
                AporteInicial: "valor em contrato",
                Perfil: "conservador e moderado"
              }
            ]
                }
    }

    return objDados;
}


    tela.innerHTML = strHtml;





