function leDados () {
    let strDados = localStorage.getItem('investimentos');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse (strDados);
    }
    else {
        objDados = { informacoes: [ 
                    { nome: "Rosângela Laís Almada", idade: "30", data_nasc: "07/02/1992", sexo: "Feminino", email: "rosangela-almada92@pinheiromanaus.com",
                    senha: "KlEXSD7P4q", cidade: "Belo Horizonte", celular: "(31) 99976-2493", profissão: "Advogado", renda: "3.000,00",
                    gastosMensaisFixos: "2.000,00", depedentes: "3"
                    },
                    { nome: "Mateus Rafael Rodrigo Martins", idade: 20, data_nasc: "17/04/2001", sexo: "Masculino", email: "mateus.rafael.martins@iacit.com.br",
                    senha: "qpLgbXbk1a", cidade: "Belo Horizonte",  celular: "(31) 99199-0106",
                    profissão: "estudante", renda: "1.500,00", gastosMensaisFixos: "1.324,00", depedentes: "0"
                    },
                    { nome: "Letícia Olivia da Rosa", idade: 22, data_nasc: "04/05/1999", sexo: "Feminino", email: "leticia-darosa97@sofisticattomoveis.com.br",
                    senha: "XoZud3k3N0", cidade: "Belo Horizonte",  celular: "(31) 99135-3523",
                    profissão: "caixa", renda: "1.250,00", gastosMensaisFixos: "1.200,00", depedentes: "0"
                    },
                    { nome: "Davi Carlos Eduardo Ian Monteiro", idade: 35, data_nasc: "24/03/1987", sexo: "Masculino", email: "davi.carlos.monteiro@damataemporionatural.com.br",
                    senha: "Ha2YI2aUuD", cidade: "Belo Horizonte", celular: "(31) 98285-0232",
                    profissão: "Aengenheiro", renda: "4.000,00", gastosMensaisFixos: "3.600,00", depedentes: "2"
                    },
                    { nome: "Sebastião Osvaldo Ferreira", idade: 21, data_nasc: "04/05/2001", sexo: "Masculino", email: "sebastiao_osvaldo_ferreira@gripoantonin.com",
                    senha: "s6lwmO7suf", cidade: "Belo Horizonte",  celular: "(31) 98888-9862",
                    profissão: "estudante", renda: "1.000,00",gastosMensaisFixos: "900,00", depedentes: "0"
                    } 
                    ]}
    }

    return objDados;
}   

function salvaDados (dados) {
    localStorage.setItem ('investimentos', JSON.stringify (dados));
}

function incluirInformacoes(){
    // Ler os dados do localStorage
    let objDados = leDados();

    // Incluir novas informações
    let strNome = document.getElementById ('campoNome').value;
    let strIdade = document.getElementById('campoIdade').value;
    let strDn = document.getElementById('camposDataNasci').value;
    let strsexo = document.getElementById('campoSexo').value;
    let strEmail = document.getElementById('campoEmail').value;
    let strSenha = document.getElementById('campoSenha').value;
    let strCidade = document.getElementById('campoCidade').value;
    let strCelular = document.getElementById ('campoCelular').value;
    let strProfissao = document.getElementById('campoProfissao').value;
    let strRenda = document.getElementById('campoRenda').value;
    let strGasto = document.getElementById('campoGastosmensais').value;
    let strDependente = document.getElementById('campoDependentes').value;
    let novaInformacoes = {
        nome: strNome,
        idade: strIdade,
        data_nasc: strDn,
        sexo: strsexo,
        email: strEmail,
        senha: strSenha,
        cidade: strCidade,
        celular: strCelular,
        profissão: strProfissao,
        renda: strRenda,
        gastos: strGasto,
        depedentes: strDependente
    };
    objDados.informacoes.push (novaInformacoes);

    // Salvar os dados no localStorage novamente
    salvaDados (objDados);

    // Atualiza os dados da tela
    imprimeDados ();
}

function imprimeDados () {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.informacoes.length; i++) {
        strHtml += `<p>${objDados.informacoes[i].nome} - ${objDados.informacoes[i].idade} - ${objDados.informacoes[i].data_nasc} - ${objDados.informacoes[i].sexo} -
        ${objDados.informacoes[i].email} - ${objDados.informacoes[i].senha} - ${objDados.informacoes[i].cidade} - ${objDados.informacoes[i].celular}
        ${objDados.informacoes[i].profissão} - ${objDados.informacoes[i].renda} - ${objDados.informacoes[i].gastosMensaisFixos} - ${objDados.informacoes[i].depedentes}</p>`
    }

    tela.innerHTML = strHtml;
}

// Configura os botões
document.getElementById ('btnCarregaDados').addEventListener ('click', imprimeDados);
document.getElementById ('btnIncluirInformacoes').addEventListener ('click', incluirInformacoes);



